# About
Simple Wrapper to detect all faces in an image and extract their embeddings.

# Installation
1. pip3 install -r requirements.txt

# Usage
1. Create an object of face_embedding.FaceImageProcessor
2. Then call process method.

# Dependencies
DeepFace: https://github.com/serengil/deepface
